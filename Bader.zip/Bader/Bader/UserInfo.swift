//
//  UserInfo.swift
//  Bader
//
//  Created by Itc on 01/02/2019.
//  Copyright © 2019 aa. All rights reserved.
//

import Foundation
class UserInfo { 
    static var userId:Int = 0
    static var userName:String = ""
} 
